class DifferenceHelper:

    def find_differences(original_recipe, recipe_make):
        pass

    